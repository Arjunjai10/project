package pnrs;

public class User {
    private int userId;
    private String username;
    private String preferences;

    public User(int userId, String username, String preferences) {
        this.userId = userId;
        this.username = username;
        this.preferences = preferences;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getPreferences() {
        return preferences;
    }
}
