package pnrs;

public class Article {
    private int id;
    private String title;
    private String category;
    private String content;

    public Article(int id, String title, String category, String content) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    // Optionally, add toString() method for easier debugging
    @Override
    public String toString() {
        return "Title: " + title + ", Category: " + category;
    }
}
