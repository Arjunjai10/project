package pnrs;

public class UserInteraction {
    private int userId;
    private int articleId;
    private String interaction;

    public UserInteraction(int userId, int articleId, String interaction) {
        this.userId = userId;
        this.articleId = articleId;
        this.interaction = interaction;
    }

    

	public int getUserId() { return userId; }
    public int getArticleId() { return articleId; }
    public String getInteraction() { return interaction; }
}
