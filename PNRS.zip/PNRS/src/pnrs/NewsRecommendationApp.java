package pnrs;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class NewsRecommendationApp {
    private static DatabaseHandler dbHandler = new MySQLDatabaseHandler();
    private static RecommendationEngine contentEngine;
    private static RecommendationEngine collaborativeEngine;

    public static void main(String[] args) {
        try {
            dbHandler.connect();
            System.out.println("Database connected successfully.");

            // Initialize engines for recommendations
            contentEngine = new ContentBasedFilteringEngine(dbHandler);
            collaborativeEngine = new CollaborativeFilteringEngine(dbHandler);

            Scanner scanner = new Scanner(System.in);

            // Get User ID and display a welcome message
            System.out.print("Enter User ID: ");
            int userId = scanner.nextInt();
            User user = dbHandler.getUserById(userId);

            if (user == null) {
                System.out.println("User not found.");
                return;
            }

            System.out.println("Welcome, " + user.getUsername() + "!");

            // Prompt for recommendation type
            System.out.println("Select Recommendation Type:");
            System.out.println("1. Content-Based Recommendations");
            System.out.println("2. Collaborative Recommendations");

            int choice;
            while (true) {
                System.out.print("Enter choice (1 or 2): ");
                choice = scanner.nextInt();
                if (choice == 1 || choice == 2) break;
                System.out.println("Invalid choice. Please enter 1 or 2.");
            }

            // Get recommended articles based on the choice
            RecommendationEngine engine = (choice == 1) ? contentEngine : collaborativeEngine;
            List<Article> recommendedArticles = RecommendationEngine.getRecommendedArticles(user);

            // Check if there are recommended articles
            if (recommendedArticles.isEmpty()) {
                System.out.println("No articles to recommend.");
            } else {
                // Display recommended articles
                System.out.println("Recommended Articles (" + (choice == 1 ? "Content-Based" : "Collaborative") + "):");
                int articleNumber = 1;
                for (Article article : recommendedArticles) {
                    System.out.println(articleNumber++ + ". " + article.getTitle() + " - Category: " + article.getCategory());
                }
            }

            // Handle article interactions
            while (true) {
                System.out.print("Enter the number of the article you’ve read (or 0 to exit): ");
                int articleChoice = scanner.nextInt();

                if (articleChoice == 0) {
                    System.out.println("Thank you! Your reading history has been updated.");
                    break;
                }

                if (articleChoice > 0 && articleChoice <= recommendedArticles.size()) {
                    Article article = recommendedArticles.get(articleChoice - 1);
                    System.out.println("You marked \"" + article.getTitle() + "\" as read.");

                    // Log the user interaction (i.e., mark the article as "read")
                    dbHandler.logUserInteraction(user.getUserId(), article.getId(), "read");

                } else {
                    System.out.println("Invalid article number. Please try again.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                dbHandler.disconnect();
                System.out.println("Database disconnected successfully.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
