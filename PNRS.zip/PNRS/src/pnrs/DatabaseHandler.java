package pnrs;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface DatabaseHandler {
    Connection connect() throws SQLException;
    void disconnect() throws SQLException;
    User getUserById(int userId) throws SQLException;
    List<Article> getAllArticles() throws SQLException;
    List<UserInteraction> getUserInteractions(int userId) throws SQLException;
    void logUserInteraction(int userId, int articleId, String interaction) throws SQLException;
	void addUser(String username, String email, String password, String preferences);
	
}
