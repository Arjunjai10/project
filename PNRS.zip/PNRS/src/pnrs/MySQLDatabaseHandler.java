package pnrs;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLDatabaseHandler implements DatabaseHandler {
    private static final String URL = "jdbc:mysql://localhost:3306/news_recommendation";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    private Connection connection;

    public Connection connect() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            return connection;
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            throw e;
        }
    }

    // Retrieve all articles from the database
    @Override
    public List<Article> getAllArticles() throws SQLException {
        List<Article> articles = new ArrayList<>();
        String query = "SELECT * FROM Articles";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("article_id");
                String title = rs.getString("title");
                String category = rs.getString("category");
                String content = rs.getString("content");
                Article article = new Article(id, title, category, content);
                articles.add(article);
            }
        }
        return articles;
    }

    // Retrieve a user by ID from the database
    @Override
    public User getUserById(int userId) throws SQLException {
        String query = "SELECT * FROM Users WHERE user_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String username = rs.getString("username");
                String preferences = rs.getString("preferences");
                System.out.println("User found: " + username);  // Debugging line
                return new User(userId, username, preferences);
            } else {
                System.out.println("No user found with ID: " + userId);  // Debugging line
            }
        }
        return null; // User not found
    }


    // Log user interaction (e.g., article read, liked)
    @Override
    public void logUserInteraction(int userId, int articleId, String interaction) throws SQLException {
        // Check if user exists
        String userCheckQuery = "SELECT 1 FROM Users WHERE user_id = ?";
        try (PreparedStatement stmtCheckUser = connection.prepareStatement(userCheckQuery)) {
            stmtCheckUser.setInt(1, userId);
            ResultSet rs = stmtCheckUser.executeQuery();
            if (!rs.next()) {
                System.out.println("User with ID " + userId + " does not exist.");
                return; // Abort logging interaction if user doesn't exist
            }
        }

        // Check if article exists
        String articleCheckQuery = "SELECT 1 FROM Articles WHERE article_id = ?";
        try (PreparedStatement stmtCheckArticle = connection.prepareStatement(articleCheckQuery)) {
            stmtCheckArticle.setInt(1, articleId);
            ResultSet rs = stmtCheckArticle.executeQuery();
            if (!rs.next()) {
                System.out.println("Article with ID " + articleId + " does not exist.");
                return; // Abort logging interaction if article doesn't exist
            }
        }

        // Log the user interaction
        String query = "INSERT INTO User_Interactions (user_id, article_id, interaction, timestamp) VALUES (?, ?, ?, NOW())";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, articleId);
            stmt.setString(3, interaction);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error logging user interaction: " + e.getMessage());
            throw e;
        }
    }


    // Disconnect from the database
    @Override
    public void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

	@Override
	public List<UserInteraction> getUserInteractions(int userId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addUser(String username, String email, String password, String preferences) {
		// TODO Auto-generated method stub
		
	}

	
}
