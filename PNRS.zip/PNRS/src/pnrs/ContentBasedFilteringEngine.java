package pnrs;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContentBasedFilteringEngine implements RecommendationEngine {
    private DatabaseHandler dbHandler;

    public ContentBasedFilteringEngine(DatabaseHandler dbHandler) {
        this.dbHandler = dbHandler;
    }

    public List<Article> getRecommendedArticles(User user) throws SQLException {
        List<Article> recommendedArticles = new ArrayList<>();

        // Mock content-based recommendation logic (filter articles by user preferences)
        String userPreferences = user.getPreferences(); // Assume preferences like "sports, politics"
        String[] preferences = userPreferences.split(",");

        // Retrieve all articles and filter them by category matching user's preferences
        List<Article> allArticles = dbHandler.getAllArticles();
        for (Article article : allArticles) {
            for (String preference : preferences) {
                if (article.getCategory().toLowerCase().contains(preference.trim().toLowerCase())) {
                    recommendedArticles.add(article);
                }
            }
        }

        return recommendedArticles;
    }
}
