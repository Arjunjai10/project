/**
 * 
 */
/**
 * 
 */
module PNRS {
	requires java.sql;
}